# setup.py
# Copyright 2011 Roger Marsh
# Licence: See LICENCE (BSD licence)

import sys
from distutils.core import setup

from version import _dptdb_version, _dpt_version


def build_dptdb():

    setup(
        name='.'.join(
            ('dptdb',
             ''.join(
                 ('py',
                  '.'.join(
                      (str(sys.version_info[0]),
                       str(sys.version_info[1]),
                       )),
                  )),
             ''.join(('dpt', _dpt_version)),
             )),
        version=_dptdb_version,
        description='SWIG interface to DPT for Python',
        author='solentware.co.uk',
        author_email='roger.marsh@solentware.co.uk',
        url='http://www.solentware.co.uk',
        package_dir={'dptdb':''},
        packages=[
            'dptdb',
            ],
        platforms='Microsoft Windows',
        package_data={
            'dptdb': ['_dptapi.pyd',
                      'LICENCE',
                      'dptapi/licence.txt',
                      ],
            },
        long_description='''SWIG interface to DPT for Python

        Built from the DPT API source code available at

        www.dptoolkit.com
        ''',
        )


if __name__ == '__main__':

    build_dptdb()

