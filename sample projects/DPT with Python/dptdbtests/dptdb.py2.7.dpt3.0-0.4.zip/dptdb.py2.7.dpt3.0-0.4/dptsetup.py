# dptsetup.py
# Copyright 2011 Roger Marsh
# Licence: See LICENCE (BSD licence)

"""Utility to build MS Windows package installer for dptdb package.

Installers for stand-alone ChessScore application, which does not need Python
to be installed separately, and for ChessScore python package to be installed
as Python scripts in a Python installation's site-packages directory can be
built.

This script expects to be run in an MSYS shell.

"""

import sys
import os
import re
import shutil
import subprocess

_dptdb_version = '0.4'


def build_chess_score():
    """Run setup scripts for DPT API interface.

    The DPT database engine is built from source using the MinGW C++ toolset
    and SWIG.  The output from this step is copied from dptapi/... to dptdb
    for convenience.

    """
    if sys.platform == 'win32':
        port = 'mingw_port'
        command = ()
    else:
        port = 'mingw_port_wine'
        command = ('wine',)

    dptapi_directory = os.path.join(
        'dptapisrc',
        'sample projects',
        'DPT with Python',
        port,
        )
    python_directory = os.path.join(
        dptapi_directory,
        'python',
        )

    api_args = ['python', 'dptsetup.py']
    target = sys.argv[1]
    if target not in (
        'clean', 'install', 'sdist', 'bdist_wininst', 'bdist_msi'):
        print 'The only targets accepted by this setup script are:'
        print ' '.join(
            ('clean', 'install', 'sdist', 'bdist_wininst', 'bdist_msi'))
        return
    if target in ('sdist', 'bdist', 'install',
                  'bdist_dumb', 'bdist_rpm', 'bdist_wininst', 'bdist_msi'):
        api_args.append('python')
        api_args.extend(sys.argv[2:])
    else:
        api_args.extend(sys.argv[1:])
    sp = subprocess.Popen(
        api_args,
        cwd=os.path.join(os.getcwd(), dptapi_directory))
    r = sp.wait()
    if not r:
        for sf in ('_dptapi.pyd', 'dptapi.py', 'version.py', 'version.pyc'):
            if os.path.isfile(os.path.join('dptdb', sf)):
                os.remove(os.path.join('dptdb', sf))
        if os.path.exists(python_directory):
            for sf in os.listdir(python_directory):
                if sf in ('_dptapi.pyd', 'dptapi.py'):
                    src = open(os.path.join(python_directory, sf), 'rb')
                    out = open(os.path.join(sf), 'wb')
                    out.write(src.read())
                    out.close()
                    src.close()
                    del out
                    del src
        if target in ('clean',):
            for sf in ('dist', 'build'):
                if os.path.isdir(sf):
                    shutil.rmtree(sf)
        if target in (
            'sdist', 'bdist', 'install',
            'bdist_dumb', 'bdist_rpm', 'bdist_wininst', 'bdist_msi',
            ):
            for arg in sys.argv:
                if arg.startswith('PYTHON_VERSION='):
                    pyversion = arg[len('PYTHON_VERSION='):]
                    break
            else:
                pyversion = ''.join(
                    (str(sys.version_info[0]), str(sys.version_info[1])))
        if target in (
            'sdist', 'bdist', 'install',
            'bdist_dumb', 'bdist_rpm', 'bdist_wininst', 'bdist_msi',
            ):
            create_dpt_version_number_module()
            setup_job = list(command)
            setup_job.extend(
                [os.path.join('c:/', ''.join(('Python', pyversion)), 'python'),
                 'setup.py',
                 target,
                 ])
            sp = subprocess.Popen(setup_job)
            r = sp.wait()


def create_dpt_version_number_module():
    """Extract DPT API version number from parmref.cpp

    This method is adapted from dptversion.py in the DPT API distribution.
    It is not appropriate to share the code between the packages.  In other
    words to amend dptversion.py to cope with this module's needs.

    """
    version_line = re.compile(''.join((
        '\s*StoreEntry.*VERSDPT.*?(?P<version>((\d+\.)*\d+))')))
    version = '0.0'
    f = open(os.path.join('dptapisrc', 'source', 'parmref.cpp'),'r')
    for t in f.readlines():
        vl = version_line.match(t)
        if vl is not None:
            version = str(vl.group('version'))
            break
    f.close()

    f = open(os.path.join('version.py'), 'wb')
    f.write(''.join(
        ('_dpt_version = ', "'", version, "'", os.linesep)
        ).encode())
    f.write(''.join(
        ('_dptdb_version = ', "'", _dptdb_version, "'", os.linesep)
        ).encode())
    f.close()


if __name__ == '__main__':

    build_chess_score()
